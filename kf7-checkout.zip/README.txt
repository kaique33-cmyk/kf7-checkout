# Checkout KF7

Como hospedar:

1. Crie um repositório público no GitHub (ex: kf7-checkout) e faça upload do arquivo index.html.
2. Ative o GitHub Pages em Settings → Pages → Source → Branch main → / (root).
3. Aguarde alguns minutos e acesse:
   https://SEUUSUARIO.github.io/kf7-checkout/

Alternativas de hospedagem rápida:
- Netlify Drop: https://app.netlify.com/drop → arraste a pasta kf7-checkout
- Vercel: https://vercel.com/import → importe o repositório
